/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import mfb2.tools.obclipse.exceptions.ObclipseException;

public class PropertyHandler extends Properties {

  private static final long serialVersionUID = -3195551814418405425L;

  private File _propertyFile;

  private String _propertyFileComment = "";

  public PropertyHandler(File propFile) {
    _propertyFile = propFile;
  }

  public PropertyHandler(Properties defaults, String filePath) {
    super(defaults);
    _propertyFile = new File(filePath);
  }

  public void loadPropertyFile() throws ObclipseException {
    Msg.println("Loading property file " + _propertyFile.getAbsolutePath());
    InputStream inStream;
    try {
      inStream = new FileInputStream(_propertyFile);
      load(inStream);
    } catch (FileNotFoundException e) {
      Msg.error("The file ''{0}'' does not exist!", e, _propertyFile.getAbsolutePath());
    } catch (IOException e) {
      Msg.error("I/O-Exception reading the file ''{0}''!", e, _propertyFile.getAbsolutePath());
    }
  }

  public void storePropertyFile()throws ObclipseException {
    Msg.println("storing property file {0}", _propertyFile);
    FileOutputStream outStream;
    try {
      outStream = new FileOutputStream(_propertyFile);
      store(outStream, _propertyFileComment);
    } catch (FileNotFoundException e) {
      Msg.error("The file ''{0}'' does not exist!", e, _propertyFile.getAbsolutePath());
    } catch (IOException e) {
      Msg.error("I/O-Exception reading the file ''{0}''!", e, _propertyFile.getAbsolutePath());
    }
  }

  public String getPropertyFileComment() {
    return _propertyFileComment;
  }

  public void setPropertyFileComment(String propertyFileComment) {
    _propertyFileComment = propertyFileComment;
  }

}
