package mfb2.tools.obclipse.util;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.CodeSource;
import java.security.ProtectionDomain;

import mfb2.tools.obclipse.exceptions.ObclipseException;

/**
 * informations about the system environment e.g. path of the project
 * 
 * @author bluemel
 */
public class SystemInfo {

  public final static String OBCLIPSE_BASE_DIR = getBaseDir();

  /**
   * Find the base directory of the tool.<br>
   * 
   * @return
   */
  public static String getBaseDir() {
    ClassLoader clsLoader = new SystemInfo().getClass().getClassLoader();
    String clsName = SystemInfo.class.getName();
    clsName = clsName.replace('.', '/') + ".class"; //$NON-NLS-1$
    URL url = clsLoader.getResource(clsName);
    String file = url.getPath();
    file = file.replace(clsName, ""); //$NON-NLS-1$
    file = file.replace("file:", ""); //$NON-NLS-1$ //$NON-NLS-2$
    String baseDirPath = new File(file).getParentFile().getAbsolutePath();
    System.out.println("Resolved base directory: " + baseDirPath);
    return baseDirPath + "/"; //$NON-NLS-1$
  }

  /**
   * returns the base directory of the project which contains the given class
   * 
   * @param clas a class of the project
   * @return the directory as URL string
   */
  public static String getBaseDir(Class<?> cls) throws ObclipseException {
    File dir = new File(getCodeBase(cls));
    File baseDir;
    if (dir.isFile()) {
      baseDir = dir.getParentFile();
      if (baseDir.getName().equals("lib")) { //$NON-NLS-1$
        baseDir = baseDir.getParentFile();
      }
    } else {
      baseDir = dir;
      String dirName = dir.getName();
      if (dirName.equals("bin") || dirName.equals("classes")) { //$NON-NLS-1$ //$NON-NLS-2$
        baseDir = dir.getParentFile();
      }
    }
    String baseDirPath = ""; //$NON-NLS-1$
    try {
      baseDirPath = baseDir.toURL().getFile();
    } catch (MalformedURLException e) {
      Msg.error("Cannot resolve base directory.\n{0}", e);
    }
    return baseDirPath;
  }

  /**
   * returns the codebase of the project which contains the given class<br>
   * e.g. /classes/ or /bin/ or /lib/xy.jar
   * 
   * @param cls a class of the project
   * @return the directory or library as URL string
   */
  public static String getCodeBase(Class<?> cls) {
    ProtectionDomain pd = cls.getProtectionDomain();
    CodeSource cs = pd.getCodeSource();
    return cs.getLocation().getFile();
  }

}
