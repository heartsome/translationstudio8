/*-------------------------------------------
 - Copyright (c) 2004-2009 aquintos GmbH.
 - All rights reserved.
 - www.aquintos.com
 ------------------------------------------*/
package mfb2.tools.obclipse.util;

import java.util.HashMap;
import java.util.Map;


/**
 * @version $Id: $
 */
public class PropertiesUtil {

  public final static String REVISION = "$Rev: $"; //$NON-NLS-1$

  public static Map<String, String> getPropertiesFromArgs(String[] args) {
    HashMap<String, String> properties = new HashMap<String, String>();
    for (String argument : args) {
      String[] argParts = argument.split("="); //$NON-NLS-1$
      if (argParts.length == 2) {
        properties.put(argParts[0], PropertiesUtil.trimEnclosingQuotes(argParts[1]));
      }
    }
    return properties;
  }

  public static String trimEnclosingQuotes(String value) {
    String trimmedValue = value;
    if (trimmedValue != null) {
      if (trimmedValue.charAt(0) == '"') {
        trimmedValue = trimmedValue.substring(1);
      }
      if (trimmedValue.charAt(trimmedValue.length() - 1) == '"') {
        trimmedValue = trimmedValue.substring(0, trimmedValue.length() - 1);
      }
    }
    return trimmedValue;
  }

}
