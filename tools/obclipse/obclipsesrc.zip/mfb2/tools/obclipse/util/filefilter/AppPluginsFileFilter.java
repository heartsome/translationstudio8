/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.util.filefilter;

import java.io.File;
import java.io.FileFilter;

import mfb2.tools.obclipse.ObclipseProps;

public class AppPluginsFileFilter implements FileFilter {

  private boolean _includeJars = true;

  private boolean _includeDirs = true;

  public AppPluginsFileFilter(boolean includeJars, boolean includeDirs) {
    super();
    _includeJars = includeJars;
    _includeDirs = includeDirs;
  }

  public boolean accept(File file) {
    if ((_includeJars && file.getName().endsWith(".jar")) || (_includeDirs && file.isDirectory())) { //$NON-NLS-1$
      for (String appPrefix : ObclipseProps.getListComma(ObclipseProps.APPLICATION_PREFIX)) {
        if (file.getName().startsWith(appPrefix)) {
          return true;
        }
      }
    }
    return false;
  }

}