/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.MessageFormat;

import mfb2.tools.obclipse.exceptions.ObclipseException;

public class Msg {

  private static final String DEFAULT_LOG_FILE_NAME = SystemInfo.OBCLIPSE_BASE_DIR + "obclipse.log"; //$NON-NLS-1$

  public static final String LOG_FILE = "logFile"; //$NON-NLS-1$

  public static final String VERBOSE = "verbose"; //$NON-NLS-1$

  private static boolean _verbose = true;

  private static PrintWriter _logFile;

  private final static String ERROR = "ERROR: "; //$NON-NLS-1$

  private final static String WARNING = "WARNING: "; //$NON-NLS-1$

  private static boolean _isPrintStackTrace = true;

  public static boolean init(String logFileName) {
    File logFile = new File(DEFAULT_LOG_FILE_NAME);
    if (logFileName != null) {
      logFile = new File(logFileName);
    }
    try {
      _logFile = new PrintWriter(logFile);
    } catch (FileNotFoundException e) {
      System.err.println("Cannot open the logfile! " + e.getMessage());
    }
    return _logFile != null;
  }

  public static void close() {
    _logFile.close();
  }

  public static void writeLog(String msg) {
    if (_logFile != null) {
      _logFile.println(msg);
    }
  }

  public static void println(String msg) {
    System.out.println(msg);
    writeLog(msg);
  }

  public static void println(String msg, Object... arguments) {
    String formattedMsg = MessageFormat.format(msg, arguments);
    println(formattedMsg);
  }

  public static void error(String msg, Throwable t) throws ObclipseException {
    String formattedMsg = ERROR + msg;
    System.err.println(formattedMsg);
    writeLog(formattedMsg);
    printStackTrace(t);
    throw new ObclipseException("Obfuscation terminates with errors!\nDetails: " + msg, t);
  }

  public static void error(String msg, Throwable t, Object... arguments) throws ObclipseException {
    String formattedMsg = MessageFormat.format(msg, arguments);
    error(formattedMsg, t);
  }

  public static void error(String msg, Object... arguments) throws ObclipseException {
    error(msg, null, arguments);
  }

  public static void printStackTrace(Throwable t) {
    if (_isPrintStackTrace && t != null) {
      t.printStackTrace(_logFile);
      t.printStackTrace();
    }
  }

  public static void warning(String msg) {
    String formattedMsg = WARNING + msg;
    System.err.println(formattedMsg);
    writeLog(formattedMsg);
  }

  public static void warning(String msg, Object... arguments) {
    String formattedMsg = MessageFormat.format(msg, arguments);
    warning(formattedMsg);
  }

  public static void verbose(String msg) {
    if (_verbose) {
      println(msg);
    }
  }

  public static void verbose(String msg, Object... arguments) {
    if (_verbose) {
      println(msg, arguments);
    }
  }

  public static void setVerbose(boolean verbose) {
    _verbose = verbose;
  }

  public static void ioException(File file, Throwable t) throws ObclipseException {
    if (file != null) {
      Msg.error("I/O-Exception processing file ''{0}''!", file.getAbsolutePath());
    } else {
      Msg.error(t.getMessage());
    }
  }

  public static void ioException(File file, File file2, Throwable t) throws ObclipseException {
    if (file != null && file2 != null) {
      Msg.error("I/O-Exception processing file ''{0}'' or ''{1}''!", file.getAbsolutePath(), file2.getAbsolutePath());
    } else {
      Msg.error(t.getMessage());
    }
  }

}
