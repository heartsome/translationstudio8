package mfb2.tools.obclipse.exceptions;

public class ObclipseException extends Exception {

  private static final long serialVersionUID = 4866324870267180286L;

  public ObclipseException(String message) {
    super(message);
  }

  /**
   * 
   */
  public ObclipseException() {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @param message
   * @param cause
   */
  public ObclipseException(String message, Throwable cause) {
    super(message, cause);
    // TODO Auto-generated constructor stub
  }

  /**
   * @param cause
   */
  public ObclipseException(Throwable cause) {
    super(cause);
    // TODO Auto-generated constructor stub
  }

}
