/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.handleproduct;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import mfb2.tools.obclipse.ObclipseProps;
import mfb2.tools.obclipse.exceptions.ObclipseException;
import mfb2.tools.obclipse.io.ZipExtractor;
import mfb2.tools.obclipse.util.Msg;
import mfb2.tools.obclipse.util.filefilter.AppPluginsFileFilter;

public class ExtractAppJars {

  private List<String> _extracedPluginDirs = new ArrayList<String>();

  public ExtractAppJars() {
  }

  public void extractApplicationJars() throws ObclipseException {
    File appDir = new File(ObclipseProps.get(ObclipseProps.APP_PLUGIN_DIR));
    Msg.println("Extracting application jars to directory ''{0}''...", appDir.getAbsolutePath());
    AppPluginsFileFilter fileFilter = new AppPluginsFileFilter(true, false);
    if (appDir.exists()) {
      File[] appDirFiles = appDir.listFiles(fileFilter);
      for (int i = 0; i < appDirFiles.length; i++) {
        File appFile = appDirFiles[i];
        if (!appFile.isDirectory()) {
          String targetDir = appDir.getAbsolutePath() + File.separator + appFile.getName();
          targetDir = targetDir.substring(0, targetDir.length() - 4);
          if (!new File(targetDir).exists()) {
            Msg.verbose("Extract " + targetDir + ".jar");
            ZipExtractor.extractZipFile(appFile.getAbsolutePath(), targetDir);
            _extracedPluginDirs.add(targetDir);
            appFile.delete();
          } else {
            Msg.error("Target dir already exists! " + targetDir);
          }
        } else {
          Msg.error("Directory could not be extracted! " + appFile.getAbsolutePath());
        }
      }
    } else {
      Msg.error("Application directory not found: " + appDir.getAbsolutePath());
    }
  }

  public List<String> getExtracedPluginDirs() {
    return _extracedPluginDirs;
  }

}
