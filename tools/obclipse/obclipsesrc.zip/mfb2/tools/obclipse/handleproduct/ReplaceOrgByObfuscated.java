/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.handleproduct;

import java.io.File;
import java.util.Set;

import mfb2.tools.obclipse.ObclipseProps;
import mfb2.tools.obclipse.exceptions.ObclipseException;
import mfb2.tools.obclipse.io.FileOperations;
import mfb2.tools.obclipse.util.Msg;

public class ReplaceOrgByObfuscated {

  public void replaceOriginalByObfuscated(Set<String> directoriesToDelete) throws ObclipseException {
    File obfPluginDir = new File(ObclipseProps.get(ObclipseProps.APP_PLUGIN_DIR) + ObclipseProps.get(ObclipseProps.OBFUSCATED_TEMP_DIR));
    if (obfPluginDir.exists()) {
      File[] obfPlugins = obfPluginDir.listFiles();
      for (File obfPlugin : obfPlugins) {
        for (String dirToDelete : directoriesToDelete) {
          File orgFile = new File(ObclipseProps.get(ObclipseProps.APP_PLUGIN_DIR) + obfPlugin.getName() + File.separator + dirToDelete);
          FileOperations.deleteDir(orgFile);
        }
        File[] obfFiles = obfPlugin.listFiles();
        for (File obfFile : obfFiles) {
          File orgFile = new File(ObclipseProps.get(ObclipseProps.APP_PLUGIN_DIR) + obfPlugin.getName() + File.separator + obfFile.getName());
          if (obfFile.isDirectory()) {
            FileOperations.copyDir(obfFile, orgFile);
          } else {
            FileOperations.copyFile(obfFile, orgFile);
          }
        }
      }
      if (!FileOperations.deleteDir(obfPluginDir)) {
        Msg.error("Cannot delete obfuscation temp directory ''{0}''!", obfPluginDir);
      }
    }
  }

}
