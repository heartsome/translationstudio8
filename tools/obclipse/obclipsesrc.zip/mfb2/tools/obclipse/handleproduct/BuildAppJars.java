/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.handleproduct;

import java.io.File;
import java.util.List;

import mfb2.tools.obclipse.ObclipseProps;
import mfb2.tools.obclipse.exceptions.ObclipseException;
import mfb2.tools.obclipse.io.FileOperations;
import mfb2.tools.obclipse.io.ZipCreator;
import mfb2.tools.obclipse.util.Msg;

public class BuildAppJars {

  public boolean buildAppJars(List<String> extracedPluginDirs) throws ObclipseException {
    boolean success = true;
    File appPluginDir = new File(ObclipseProps.get(ObclipseProps.APP_PLUGIN_DIR));
    if (appPluginDir.exists()) {
      for (String pluginDir : extracedPluginDirs) {
        File plugin = new File(pluginDir);
        if (plugin.exists()) {
          Msg.verbose("Create '" + pluginDir + ".jar'...");
          if (ZipCreator.createZipFile(pluginDir + ".jar", plugin)) { //$NON-NLS-1$
            success &= FileOperations.deleteDir(plugin);
          }
        }
      }
    }
    return success;
  }

}
