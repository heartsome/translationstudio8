/**
 * This file is part of Obclipse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import mfb2.tools.obclipse.collectinfos.CollectApplicationPlugins;
import mfb2.tools.obclipse.collectinfos.CollectLibraries;
import mfb2.tools.obclipse.collectinfos.FilterApplicationPlugins;
import mfb2.tools.obclipse.exceptions.ObclipseException;
import mfb2.tools.obclipse.fixspecfiles.FixSpecPluginFiles;
import mfb2.tools.obclipse.handleproduct.BuildAppJars;
import mfb2.tools.obclipse.handleproduct.ExtractAppJars;
import mfb2.tools.obclipse.handleproduct.ReplaceOrgByObfuscated;
import mfb2.tools.obclipse.obfuscation.IObfuscator;
import mfb2.tools.obclipse.obfuscation.proguard.ProGuardObfuscator;
import mfb2.tools.obclipse.util.Msg;
import mfb2.tools.obclipse.util.PropertiesUtil;
import mfb2.tools.obclipse.util.SystemInfo;

public class Obclipse {

  public static String _obclipseVersion;


  public static void main(String[] args) {
    Map<String, String> properties = PropertiesUtil.getPropertiesFromArgs(args);
    Obclipse obfTool = new Obclipse();
    try {
      obfTool.init(properties);
      obfTool.processProduct();
    } catch (ObclipseException e) {
      System.err.println(e.getMessage());
    } finally {
      obfTool.shutdown();
    }
  }

  public Obclipse() {
    // nothing to do
  }

  public boolean init(Map<String, String> cmdLineProperties) throws ObclipseException {
    Msg.init(cmdLineProperties.get(Msg.LOG_FILE));
    obclipseVersion();
    ObclipseProps props = new ObclipseProps(cmdLineProperties);
    props.initPropertyValues();
    Msg.setVerbose(ObclipseProps.getBoolean(Msg.VERBOSE));
    return true;
  }

  private void obclipseVersion() throws ObclipseException {
    File manifestFile = new File(SystemInfo.OBCLIPSE_BASE_DIR + "META-INF/MANIFEST.MF"); //$NON-NLS-1$
    try {
      InputStream inStream = new FileInputStream(manifestFile);
      Manifest mf = new Manifest(inStream);
      _obclipseVersion = (String) mf.getMainAttributes().get(new Attributes.Name("Bundle-Version")); //$NON-NLS-1$
    } catch (IOException e) {
      Msg.ioException(manifestFile, e);
    }
    Msg.println("Obclipse version " + _obclipseVersion);
  }

  public void processProduct() throws ObclipseException {
    File appDir = new File(ObclipseProps.get(ObclipseProps.APPLICATION_DIRECTORY));
    Msg.println("Processing product in directory '" + appDir.getAbsolutePath() + "'");
    if (!appDir.exists()) {
      Msg.error("Application directory does not exist! Abort obfuscation!");
    }
    Msg.println("Extracting application jars...");
    ExtractAppJars extrAppJars = new ExtractAppJars();
    extrAppJars.extractApplicationJars();
    Msg.println("Collecting application information...");
    CollectLibraries collLibJars = new CollectLibraries();
    List<String> libraries = collLibJars.collectJars();
    CollectApplicationPlugins collAppInJars = new CollectApplicationPlugins();
    HashMap<String, String> appInPlugins = collAppInJars.colllectAppInJars();
    FilterApplicationPlugins filterAppPlugins = new FilterApplicationPlugins();
    filterAppPlugins.filterApplicationPlugins(appInPlugins, libraries);
    Msg.println("Executing obfuscation...");
    IObfuscator obfuscator = new ProGuardObfuscator();
    obfuscator.createObfuscatorConfiguration(new File(ObclipseProps.get(ObclipseProps.OBFUSCATOR_CONFIG_FILE)), libraries, appInPlugins);
    if (!obfuscator.executeObfucation()) {
      Msg.error("The obfuscator abort with an error! Obfuscation process stopped!");
    }
    HashMap<String, String> obfuscationMapping = obfuscator.getObfuscatedClassNames(new File(ObclipseProps.get(ObclipseProps.MAPPING_FILE_NAME)));
    Msg.println("Fix special files of the plugins...");
    FixSpecPluginFiles fixSpec = new FixSpecPluginFiles(obfuscationMapping, appInPlugins);
    fixSpec.fixSpecialPluginFiles();
    Msg.println("Copy obfuscated files back to application...");
    ReplaceOrgByObfuscated replacer = new ReplaceOrgByObfuscated();
    replacer.replaceOriginalByObfuscated(obfuscator.getDirectoriesToDelete());
    Msg.println("Rebuild extracted application jars...");
    BuildAppJars buildAppJars = new BuildAppJars();
    buildAppJars.buildAppJars(extrAppJars.getExtracedPluginDirs());
    Msg.println("The obfuscation process of the product is finished.");
  }

  public void shutdown() {
    Msg.close();
  }

}
