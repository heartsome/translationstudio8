/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import mfb2.tools.obclipse.exceptions.ObclipseException;
import mfb2.tools.obclipse.util.Msg;

public class ZipExtractor {

  /**
   * extract the zip file into the target directory
   * 
   * @param zipFile the complete path of the zip file
   * @param targetDir the complete path to the target directory
   * @return true if successfully extracted
   */
  public static boolean extractZipFile(String zipFilePath, String targetDir) throws ObclipseException {
    boolean success = false;
    File zipFile = new File(zipFilePath);
    try {
      ZipInputStream zin = new ZipInputStream(new FileInputStream(zipFile));
      ZipEntry zipEntry;
      while ((zipEntry = zin.getNextEntry()) != null) {
        String entryName = zipEntry.getName();
        String targetFilePath = targetDir + File.separator + entryName;
        if (zipEntry.isDirectory()) {
          new File(targetFilePath).mkdirs();
          continue;
        }
        extractOneEntry(zin, targetFilePath);
      }
      zin.close();
      success = true;
    } catch (FileNotFoundException e) {
      Msg.error("The zip file ''{0}'' does not exist!", zipFile.getAbsolutePath());
    } catch (IOException e) {
      Msg.ioException(zipFile, e);
    }
    return success;
  }

  /**
   * extract one zip entry of the zip file<br>
   * missing directories are created
   * 
   * @param zipInStream
   * @param targetFilePath
   * @throws IOException
   */
  private static void extractOneEntry(ZipInputStream zipInStream, String targetFilePath) throws IOException {
    File targetFile = new File(targetFilePath);
    File parentDir = targetFile.getParentFile();
    if (parentDir != null) {
      parentDir.mkdirs();
    }
    FileOutputStream outStream = new FileOutputStream(targetFile);
    byte[] b = new byte[2048];
    int len;
    while ((len = zipInStream.read(b)) != -1) {
      outStream.write(b, 0, len);
    }
    outStream.close();
  }

}
