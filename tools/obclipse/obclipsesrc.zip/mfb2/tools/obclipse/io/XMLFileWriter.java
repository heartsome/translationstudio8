/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.io;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import mfb2.tools.obclipse.exceptions.ObclipseException;
import mfb2.tools.obclipse.util.Msg;

import org.w3c.dom.Document;

public class XMLFileWriter {

  public static boolean writeXMLFile(Document doc, File xmlFile) throws ObclipseException {
    boolean success = false;
    TransformerFactory xmlTransformerFactory = TransformerFactory.newInstance();
    try {
      Transformer xmlTransformer = xmlTransformerFactory.newTransformer();
      FileOutputStream fileOutStream = new FileOutputStream(xmlFile);
      OutputStreamWriter outStreamWriter = new OutputStreamWriter(fileOutStream, doc.getXmlEncoding());
      xmlTransformer.transform(new DOMSource(doc), new StreamResult(outStreamWriter));
      outStreamWriter.close();
      success = true;
    } catch (TransformerConfigurationException e) {
      Msg.error(e.getMessageAndLocation(), e);
    } catch (TransformerException e) {
      Msg.error(e.getMessageAndLocation(), e);
    } catch (IOException e) {
      Msg.ioException(xmlFile, e);
    }
    return success;
  }

}
