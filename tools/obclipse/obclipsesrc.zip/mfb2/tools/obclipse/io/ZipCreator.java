/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import mfb2.tools.obclipse.exceptions.ObclipseException;
import mfb2.tools.obclipse.util.Msg;

public class ZipCreator {

  /**
   * creates a zip file including all files and directories of the given directory<br>
   * the paths inside of the zip file are stored relative to the given directory
   * 
   * @param theArchiveName the path and name of the target zip file
   * @param theDirectory the directory to zip
   * @return
   */
  public static boolean createZipFile(String targetArchivePath, File sourceDirectory) throws ObclipseException {
    if (sourceDirectory.isDirectory()) {
      List<File> fileList = new ArrayList<File>();
      processFileList(sourceDirectory, fileList);
      return createZipFile(targetArchivePath, sourceDirectory, fileList);
    } else {
      Msg.error("Cannot zip directory ''{0}''! It's not a directory!", sourceDirectory);
      return false;
    }
  }

  /**
   * creates a zip file from the given file list
   * 
   * @param archivePath the path and name of the target zip file
   * @param baseDir the directory that defines the relative path of the files of the zip file
   * @param files the list of files to included in the zip file
   * @return true if zip file was successfully created
   */
  public static boolean createZipFile(String targetArchivePath, File baseDir, List<File> files) throws ObclipseException {
    boolean success = false;
    byte[] buf = new byte[2048];
    File archive = new File(targetArchivePath);
    if (archive.getParentFile() != null && !archive.getParentFile().exists()) {
      archive.getParentFile().mkdirs();
    }
    Msg.verbose("Creating zip file ''{0}''...", archive);
    if (!baseDir.exists()) {
      Msg.error("The given base directory ''{0}'' does not exist!", baseDir.getAbsolutePath());
      return false;
    }
    try {
      ZipOutputStream outZip = new ZipOutputStream(new FileOutputStream(targetArchivePath));
      for (File file : files) {
        if (!file.exists()) {
          Msg.error("The given file ''{0}'' does not exist! File skipped!", file.getAbsolutePath());
          continue;
        }
        FileInputStream in = new FileInputStream(file);
        String filePath = file.getAbsolutePath();
        filePath = filePath.replaceAll("\\\\", "/"); //$NON-NLS-1$ //$NON-NLS-2$
        String baseDirPath = baseDir.getAbsolutePath();
        baseDirPath = baseDirPath.replaceAll("\\\\", "/") + "/"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        String archiveFilePath = filePath.replaceAll(baseDirPath, ""); //$NON-NLS-1$
        outZip.putNextEntry(new ZipEntry(archiveFilePath));
        int len;
        while ((len = in.read(buf)) > 0) {
          outZip.write(buf, 0, len);
        }
        outZip.closeEntry();
        in.close();
      }
      outZip.close();
      success = true;
      Msg.verbose("Zip file SUCCESSFULLY created.");
    } catch (IOException e) {
      Msg.ioException(archive, e);
    }
    return success;
  }

  /**
   * process recusive the subdirectories and put all the files in the fileList
   * 
   * @param fileList the list to store the files
   * @param directory the start directory
   */
  private static void processFileList(File directory, List<File> fileList) {
    File[] files = directory.listFiles();
    for (int i = 0; i < files.length; i++) {
      if (files[i].isDirectory()) {
        processFileList(files[i], fileList);
      } else {
        fileList.add(files[i]);
      }
    }
  }

}
