/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.fixspecfiles;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.jar.Attributes;
import java.util.jar.Manifest;
import java.util.jar.Attributes.Name;

import mfb2.tools.obclipse.ObclipseProps;
import mfb2.tools.obclipse.exceptions.ObclipseException;
import mfb2.tools.obclipse.util.Msg;

public class FixManifestMF extends AbstractFixSpecFiles {

  private static final String MANIFEST_MF = "/META-INF/MANIFEST.MF"; //$NON-NLS-1$

  private static final Name BUNDLE_ACTIVATOR = new Name("Bundle-Activator"); //$NON-NLS-1$

  private static final Name EXPORT_PACKAGE = new Name("Export-Package"); //$NON-NLS-1$

  private static final Name MAIN_CLASS = new Name("Main-Class"); //$NON-NLS-1$

  public FixManifestMF(HashMap<String, String> obfuscatedClassNames) {
    super(obfuscatedClassNames);
  }

  public void processManifest(String pluginName) throws ObclipseException {
    File manifestFile = new File(ObclipseProps.get(ObclipseProps.APP_PLUGIN_DIR) + pluginName + MANIFEST_MF);
    if (manifestFile.exists()) {
      FileInputStream fileInputStream = null;
      FileOutputStream fileOutputStream = null;
      try {
        fileInputStream = new FileInputStream(manifestFile);
        Manifest manifest = new Manifest(fileInputStream);
        fileInputStream.close();
        Attributes mainAttributes = manifest.getMainAttributes();
        String activatorClass = mainAttributes.getValue(BUNDLE_ACTIVATOR);
        if (activatorClass != null) {
          String obfClassName = _obfuscatedClassNames.get(activatorClass);
          if (obfClassName != null && !obfClassName.equals(activatorClass)) {
            Msg.verbose("Replace: " + activatorClass + "->" + obfClassName);
            mainAttributes.put(BUNDLE_ACTIVATOR, obfClassName);
          }
        }
        String exportPackage = mainAttributes.getValue(EXPORT_PACKAGE);
        if (exportPackage != null) {
          mainAttributes.put(EXPORT_PACKAGE, ObclipseProps.get(ObclipseProps.OB_DEFAULT_PACKAGE_NAME).trim() + ',' + exportPackage);
        }
        String mainClass = mainAttributes.getValue(MAIN_CLASS);
        if (mainClass != null) {
          String obfClassName = _obfuscatedClassNames.get(mainClass);
          if (obfClassName != null && !obfClassName.equals(mainClass)) {
            Msg.verbose("Replace: " + mainClass + "->" + obfClassName);
            mainAttributes.put(MAIN_CLASS, obfClassName);
          }
        }
        fileOutputStream = new FileOutputStream(manifestFile);
        manifest.write(fileOutputStream);
      } catch (FileNotFoundException e) {
        Msg.error("The file ''{0}'' does not exist!", e, manifestFile.getAbsolutePath());
      } catch (IOException e) {
        Msg.ioException(manifestFile, e);
      } finally {
        try {
          if (fileInputStream != null) {
            fileInputStream.close();
          }
        } catch (IOException e) {
          Msg.ioException(manifestFile, e);
        }
        try {
          if (fileOutputStream != null) {
            fileOutputStream.close();
          }
        } catch (IOException e) {
          Msg.ioException(manifestFile, e);
        }
      }
    }
  }

  private void processAttributes(Attributes attributes) {
    for (Entry<Object, Object> entry : attributes.entrySet()) {
      Name key = (Name) entry.getKey();
      String value = (String) entry.getValue();
      if (!key.equals(BUNDLE_ACTIVATOR) && !key.equals(EXPORT_PACKAGE)) {
        if (value != null) {
          attributes.put(key, processValue(value));
        }
      }
    }
  }

}
