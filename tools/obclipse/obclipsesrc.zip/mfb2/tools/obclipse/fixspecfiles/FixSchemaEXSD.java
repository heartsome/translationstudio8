/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.fixspecfiles;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;

import mfb2.tools.obclipse.ObclipseProps;
import mfb2.tools.obclipse.exceptions.ObclipseException;
import mfb2.tools.obclipse.io.XMLFileReader;
import mfb2.tools.obclipse.io.XMLFileWriter;
import mfb2.tools.obclipse.util.Msg;

import org.w3c.dom.Document;

public class FixSchemaEXSD extends AbstractFixSpecFiles {

  public FixSchemaEXSD(HashMap<String, String> obfuscatedClassNames) {
    super(obfuscatedClassNames);
    _exclusionIds = new HashSet<String>(ObclipseProps.getListComma(ObclipseProps.KEEP_SCHEMA_EXSD_IDS));
  }

  public void processSchemaXmls(String pluginName) throws ObclipseException {
    File schemaDir = new File(ObclipseProps.get(ObclipseProps.APP_PLUGIN_DIR) + pluginName + "/schema");
    if (schemaDir.exists() && schemaDir.isDirectory()) {
      File[] schemaFiles = schemaDir.listFiles(new FileFilter() {

        public boolean accept(File pathname) {
          if (pathname.getName().endsWith(".exsd")) { //$NON-NLS-1$
            return true;
          }
          return false;
        }

      });
      for (File schemaFile : schemaFiles) {
        Document schemaDoc = XMLFileReader.readXMLFile(schemaFile);
        if (schemaDoc != null) {
          fixXMLDocumentElements(schemaDoc);
          File obfSchemaFile = new File(schemaFile.getAbsolutePath() + ".tmp"); //$NON-NLS-1$
          try {
            obfSchemaFile.createNewFile();
          } catch (IOException e) {
            Msg.ioException(obfSchemaFile, e);
          }
          if (XMLFileWriter.writeXMLFile(schemaDoc, obfSchemaFile)) {
            schemaFile.delete();
            obfSchemaFile.renameTo(schemaFile);
          }
        }
      }
    }
  }

}
