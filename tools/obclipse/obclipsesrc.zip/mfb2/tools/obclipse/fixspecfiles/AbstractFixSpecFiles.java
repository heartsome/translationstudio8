/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.fixspecfiles;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import mfb2.tools.obclipse.util.Msg;

import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class AbstractFixSpecFiles {

  private static final String[] _valuePrefixes = new String[] {":"}; //$NON-NLS-1$

  protected Map<String, String> _obfuscatedClassNames;

  protected Set<String> _exclusionIds;

  public AbstractFixSpecFiles(HashMap<String, String> obfuscatedClassNames) {
    super();
    _obfuscatedClassNames = obfuscatedClassNames;
  }

  /**
   * fix the given node and recursive all of its child nodes
   * 
   * @param node
   * @return true if at least one value was changed
   */
  protected boolean fixXMLDocumentElements(Node node) {
    boolean replaceOccured = false;
    NamedNodeMap atts = node.getAttributes();
    if (atts != null) {
      for (int i = 0; i < atts.getLength(); i++) {
        Node att = atts.item(i);
        if (!_exclusionIds.contains(att.getNodeName())) {
          for (int j = 0; j < _valuePrefixes.length; j++) {
            if (fixNodeValue(att, _valuePrefixes[j])) {
              replaceOccured = true;
              break;
            }
          }
        }
      }
    }
    for (Node child = node.getFirstChild(); child != null; child = child.getNextSibling()) {
      replaceOccured |= fixXMLDocumentElements(child);
    }
    return replaceOccured;
  }

  private boolean fixNodeValue(Node att, String valuePrefix) {
    String nodeValue = att.getNodeValue();
    String prefix = new String();
    if (nodeValue.startsWith(valuePrefix)) {
      prefix = valuePrefix;
      nodeValue = nodeValue.replaceFirst(prefix, ""); //$NON-NLS-1$
    }
    String obfClassName = _obfuscatedClassNames.get(nodeValue);
    if (obfClassName != null && !obfClassName.equals(nodeValue)) {
      Msg.verbose("Replace: " + prefix + nodeValue + "->" + prefix + obfClassName);
      att.setNodeValue(prefix + obfClassName);
      return true;
    }
    return false;
  }

  /**
   * Process a string value for a fully qualified java identifier.
   * 
   * @param value
   * @return a new string where all fully qualified java identifiers are replaced by their ofbuscated identifier.
   */
  protected String processValue(String value) {
    StringBuffer newValue = new StringBuffer();
    char[] charArray = value.toCharArray();
    StringBuffer javaIdentifierBuffer = new StringBuffer();
    for (int i = 0; i < charArray.length; i++) {
      char character = charArray[i];
      if (Character.isJavaIdentifierPart(character) || character == '.') {
        javaIdentifierBuffer.append(character);
      } else {
        newValue.append(getReplaceValue(javaIdentifierBuffer.toString()));
        newValue.append(character);
        javaIdentifierBuffer = new StringBuffer();
      }
    }
    newValue.append(getReplaceValue(javaIdentifierBuffer.toString()));
    return newValue.toString();
  }

  private String getReplaceValue(String javaIdentifier) {
    String obfClassName = _obfuscatedClassNames.get(javaIdentifier);
    if (obfClassName != null && !obfClassName.equals(javaIdentifier)) {
      Msg.verbose("Replace: " + javaIdentifier + "->" + obfClassName);
      return obfClassName;
    } else {
      return javaIdentifier;
    }
  }

}
