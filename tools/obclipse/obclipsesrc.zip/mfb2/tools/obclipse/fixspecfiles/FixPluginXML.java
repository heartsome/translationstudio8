/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.fixspecfiles;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;

import mfb2.tools.obclipse.ObclipseProps;
import mfb2.tools.obclipse.exceptions.ObclipseException;
import mfb2.tools.obclipse.io.XMLFileReader;
import mfb2.tools.obclipse.io.XMLFileWriter;
import mfb2.tools.obclipse.util.Msg;

import org.w3c.dom.Document;

public class FixPluginXML extends AbstractFixSpecFiles {

  public FixPluginXML(HashMap<String, String> obfuscatedClassNames) {
    super(obfuscatedClassNames);
    _exclusionIds = new HashSet<String>(ObclipseProps.getListComma(ObclipseProps.KEEP_PLUGIN_XML_IDS));
  }

  public void processPluginXml(String pluginName) throws ObclipseException {
    String appPluginDir = ObclipseProps.get(ObclipseProps.APP_PLUGIN_DIR);
    File pluginFile = new File(appPluginDir + pluginName + "/plugin.xml"); //$NON-NLS-1$
    if (!pluginFile.exists()) {
      pluginFile = new File(appPluginDir + pluginName + "/fragment.xml"); //$NON-NLS-1$
    }
    if (pluginFile.exists()) {
      Document pluginDoc = XMLFileReader.readXMLFile(pluginFile);
      if (pluginDoc != null) {
        if (fixXMLDocumentElements(pluginDoc)) {
          File obfPluginFile = new File(pluginFile.getAbsolutePath() + ".tmp"); //$NON-NLS-1$
          try {
            obfPluginFile.createNewFile();
          } catch (IOException e) {
            Msg.ioException(obfPluginFile, e);
          }
          XMLFileWriter.writeXMLFile(pluginDoc, obfPluginFile);
          if (!pluginFile.delete()) {
            Msg.error("The file ''{0}'' could not be deleted!", pluginFile.getAbsolutePath());
          }
          if (!obfPluginFile.renameTo(pluginFile)) {
            Msg.error("Fixed file ''{0}'' could not be renamed!", obfPluginFile.getAbsolutePath());
          }
        }
      }
    }
  }

}
