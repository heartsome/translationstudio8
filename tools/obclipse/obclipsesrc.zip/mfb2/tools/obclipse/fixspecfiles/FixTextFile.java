/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.fixspecfiles;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import mfb2.tools.obclipse.ObclipseProps;
import mfb2.tools.obclipse.exceptions.ObclipseException;
import mfb2.tools.obclipse.io.FileOperations;
import mfb2.tools.obclipse.util.Msg;

public class FixTextFile extends AbstractFixSpecFiles {

  public FixTextFile(HashMap<String, String> obfuscatedClassNames) {
    super(obfuscatedClassNames);
  }

  public boolean fixTextFiles(String pluginFileName, List<String> filesToFix) throws ObclipseException {
    boolean success = true;
    List<String> ids = ObclipseProps.getListComma(ObclipseProps.PACKAGE_PATHS);
    if (pluginFileName.endsWith(".jar")) {
      pluginFileName = pluginFileName.substring(0, pluginFileName.length() - 4);
    }
    String pluginPath = ObclipseProps.get(ObclipseProps.APP_PLUGIN_DIR) + pluginFileName + File.separator;
    for (String fileToFixName : filesToFix) {
      File file = new File(pluginPath + fileToFixName);
      if (file.exists()) {
        Msg.println("Fix file '" + file.getAbsolutePath() + "'");
        StringBuffer buffer = new StringBuffer(FileOperations.readFileToSting(file));
        StringBuffer newBuffer = new StringBuffer(buffer.capacity());
        boolean firstPass = true;
        for (String id : ids) {
          int startIndex = 0, oldStartIndex = 0;
          int replacedClassNames = 0;
          if (!firstPass) {
            buffer = newBuffer;
            newBuffer = new StringBuffer(buffer.capacity());
          }
          firstPass = false;
          while (startIndex <= buffer.length()) {
            startIndex = buffer.indexOf(id, startIndex);
            if (startIndex == -1) {
              break;
            }
            int index = startIndex;
            while (true) {
              char c = buffer.charAt(index++);
              if (!Character.isJavaIdentifierPart(c) && c != '.') {
                break;
              }
            }
            String className = buffer.substring(startIndex, --index);
            newBuffer.append(buffer.substring(oldStartIndex, startIndex));
            String obfClassName = _obfuscatedClassNames.get(className);
            if (obfClassName != null) {
              Msg.verbose("Replace: " + className + "->" + obfClassName);
              newBuffer.append(obfClassName);
            }
            replacedClassNames++;
            oldStartIndex = index;
            startIndex = index;
          }
          newBuffer.append(buffer.substring(oldStartIndex, buffer.length()));
          Msg.verbose("Replaced class names for id '" + id + "': " + replacedClassNames);
        }
        File tempFile = new File(pluginPath + fileToFixName + ".tmp");
        FileOperations.writeStingToFile(tempFile, newBuffer.toString());
        file.delete();
        tempFile.renameTo(file);
      }
    }
    return success;
  }

}
