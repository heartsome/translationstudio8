/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.obfuscation;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import mfb2.tools.obclipse.exceptions.ObclipseException;

public interface IObfuscator {

  public boolean createObfuscatorConfiguration(File configFile, List<String> libraries, HashMap<String, String> obfuscationSources)
      throws ObclipseException;

  public boolean executeObfucation() throws ObclipseException;

  public HashMap<String, String> getObfuscatedClassNames(File mappingFile) throws ObclipseException;

  public Set<String> getDirectoriesToDelete() throws ObclipseException;

}
