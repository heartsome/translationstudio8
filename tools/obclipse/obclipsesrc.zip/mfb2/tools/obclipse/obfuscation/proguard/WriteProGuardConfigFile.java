/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.obfuscation.proguard;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import mfb2.tools.obclipse.ObclipseProps;
import mfb2.tools.obclipse.exceptions.ObclipseException;
import mfb2.tools.obclipse.io.TextFileWriter;
import mfb2.tools.obclipse.util.Msg;

public class WriteProGuardConfigFile {

  private TextFileWriter _configFileWriter;

  private List<String> _libraries;

  private HashMap<String, String> _obfuscationSources;

  public WriteProGuardConfigFile(List<String> libraries, HashMap<String, String> obfuscationSources) {
    _libraries = libraries;
    _obfuscationSources = obfuscationSources;
  }

  public void writeConfigFile(String obfuscationConfigFile, String obfuscationParameterFile) throws ObclipseException {
    File configFile = new File(obfuscationConfigFile);
    Msg.println("Create configuration file for ProGuard: " + configFile.getAbsolutePath());
    _configFileWriter = new TextFileWriter();
    _configFileWriter.createConfigFile(configFile);
    addDefaultConfigFile(obfuscationParameterFile);
    addAdditionalParameter();
    addLibraries();
    addObfuscationSources();
    _configFileWriter.closeConfigFile();
  }

  /**
   * Add additional parameters from config file where placeholders are parsed.
   */
  private void addAdditionalParameter() {
    List<String> listComma = ObclipseProps.getListComma(ObclipseProps.PROGUARD_ADDITIONAL_PARAMETER);
    for (String additionalParameter : listComma) {
      _configFileWriter.writeLine("   " + additionalParameter);
    }
  }

  private void addDefaultConfigFile(String obfuscationParameterFile) throws ObclipseException {
    _configFileWriter.writeLine("   -libraryjars \"" + ObclipseProps.get(ObclipseProps.JAVA_HOME) + "/lib/rt.jar\"");
    _configFileWriter.writeLine("   -printmapping \"" + ObclipseProps.get(ObclipseProps.MAPPING_FILE_NAME) + "\"");
    String mappingFileNameToApply = ObclipseProps.get(ObclipseProps.MAPPING_FILE_NAME_TO_APPLY);
    if (mappingFileNameToApply != null && !"".equals(mappingFileNameToApply)) {
      _configFileWriter.writeLine("   -applymapping \"" + mappingFileNameToApply + "\"");
    }
    File paramFile = new File(obfuscationParameterFile);
    Msg.println("Read proguard default config file ''{0}''.", paramFile.getAbsolutePath());
    try {
      BufferedReader reader = new BufferedReader(new FileReader(paramFile));
      String line;
      while ((line = reader.readLine()) != null) {
        _configFileWriter.writeLine(line);
      }
    } catch (FileNotFoundException e) {
      Msg.error("The parameter file ''{0}'' does not exist!", e, paramFile.getAbsolutePath());
    } catch (IOException e) {
      Msg.ioException(paramFile, e);
    }
  }

  private void addObfuscationSources() {
    _configFileWriter.writeLine("");
    for (Entry<String, String> pluginEntry : _obfuscationSources.entrySet()) {
      _configFileWriter.writeLine("   -injars  \"" + ObclipseProps.get(ObclipseProps.APP_PLUGIN_DIR) + pluginEntry.getValue() + "\""
                                  + ObclipseProps.get(ObclipseProps.PROGUARD_FILTER));
      _configFileWriter.writeLine("   -outjars \"" + ObclipseProps.get(ObclipseProps.APP_PLUGIN_DIR)
                                  + ObclipseProps.get(ObclipseProps.OBFUSCATED_TEMP_DIR) + "/" + pluginEntry.getValue() + "\"");
    }
  }

  private void addLibraries() {
    _configFileWriter.writeLine("");
    for (String library : _libraries) {
      _configFileWriter.writeLine("   -libraryjars \"" + library + "\"");
    }
  }

}
