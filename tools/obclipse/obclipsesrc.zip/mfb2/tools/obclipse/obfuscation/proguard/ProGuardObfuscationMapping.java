/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.obfuscation.proguard;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import mfb2.tools.obclipse.exceptions.ObclipseException;
import mfb2.tools.obclipse.util.Msg;
import proguard.obfuscate.MappingProcessor;
import proguard.obfuscate.MappingReader;

public class ProGuardObfuscationMapping implements MappingProcessor {

  private HashMap<String, String> _obfuscatedClassName = new HashMap<String, String>();

  public ProGuardObfuscationMapping() {
    // nothing to do
  }

  public boolean readMappingFile(File mappingFile) throws ObclipseException {
    MappingReader reader = new MappingReader(mappingFile);
    try {
      reader.pump(this);
      return true;
    } catch (IOException e) {
      Msg.ioException(mappingFile, e);
    }
    return false;
  }

  /**
   * used on proguard version 4.x
   */
  public boolean processClassMapping(String orgClassName, String obfuscatedClassName) {
    if (_obfuscatedClassName.put(orgClassName, obfuscatedClassName) != null) {
      String message = "duplicated classes in project found: " + orgClassName;
      Msg.writeLog(message);
      System.err.println(message);
      return false;
    }
    return true;
  }

  /**
   * used on progard version 3.x
   */
  public boolean processClassFileMapping(String orgClassName, String obfuscatedClassName) {
    if (_obfuscatedClassName.put(orgClassName, obfuscatedClassName) != null) {
      String message = "duplicated classes in project found: " + orgClassName;
      Msg.writeLog(message);
      System.err.println(message);
      return false;
    }
    return true;
  }

  public void processFieldMapping(String s, String s1, String s2, String s3) {
    // nothing to do
  }

  public void processMethodMapping(String s, int i, int j, String s1, String s2, String s3) {
    // nothing to do
  }

  /**
   * @see proguard.obfuscate.MappingProcessor#processMethodMapping(java.lang.String, int, int, java.lang.String, java.lang.String, java.lang.String,
   *      java.lang.String)
   * @since proguard 4.4
   */
  public void processMethodMapping(String arg0, int arg1, int arg2, String arg3, String arg4, String arg5, String arg6) {
    // nothing to do
  }

  public HashMap<String, String> getObfuscatedClassName() {
    return _obfuscatedClassName;
  }

}
