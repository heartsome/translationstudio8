/*-------------------------------------------
 - Copyright (c) 2004-2009 aquintos GmbH.
 - All rights reserved.
 - www.aquintos.com
 ------------------------------------------*/
package mfb2.tools.obclipse.obfuscation.proguard;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import mfb2.tools.obclipse.ObclipseProps;
import mfb2.tools.obclipse.exceptions.ObclipseException;
import mfb2.tools.obclipse.util.Msg;

/**
 * (zip;ear;war;jar;mfb2/**,mfb2/tools/**), (zip;;;jar;mfb2/tools/**), (jar;filter)
 */
public class ProguardClassPathFilter {

  public Set<String> getFilterBasePaths() throws ObclipseException {
    return parseFilter(ObclipseProps.get(ObclipseProps.PROGUARD_FILTER));
  }

  private Set<String> parseFilter(String classPathEntry) throws ObclipseException {
    Set<String> basePaths = new HashSet<String>();
    String filter = extractFilterFromClassPath(classPathEntry);
    String[] filterSplit = filter.split(";"); //$NON-NLS-1$
    if (filterSplit.length > 0) {
      String pathFilter = filterSplit[filterSplit.length - 1];
      String[] pathSplit = pathFilter.split(","); //$NON-NLS-1$
      if (pathSplit.length > 0) {
        for (String path : pathSplit) {
          String pathBaseDir = extractPathBaseDir(path);
          basePaths.add(pathBaseDir);
        }
      }
    }
    Msg.println("Plugin subdirectories to delete: " + basePaths);
    return basePaths;
  }

  private String extractFilterFromClassPath(String classPathEntry) {
    Pattern fsPattern = Pattern.compile("\\([^\\(^\\)]*\\)"); //$NON-NLS-1$
    Matcher matcher = fsPattern.matcher(classPathEntry);
    matcher.find();
    int start = matcher.start();
    int end = matcher.end();
    return classPathEntry.substring(start + 1, end - 1);
  }

  private String extractPathBaseDir(String path) throws ObclipseException {
    String basePath = path.replaceAll("!", ""); //$NON-NLS-1$ //$NON-NLS-2$
    if ('/' == basePath.charAt(0)) {
      basePath = basePath.substring(1);
    }
    int index = basePath.indexOf('/');
    basePath = basePath.substring(0, index);
    if (basePath.contains("*") || basePath.contains("?")) { //$NON-NLS-1$ //$NON-NLS-2$
      Msg.error("'*' and '?' is not allowed in the base path");
    }
    return basePath;
  }

}
