/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.obfuscation.proguard;

import java.io.File;
import java.io.IOException;

import mfb2.tools.obclipse.exceptions.ObclipseException;
import mfb2.tools.obclipse.util.Msg;
import proguard.Configuration;
import proguard.ConfigurationParser;
import proguard.ParseException;
import proguard.ProGuard;

public class ProGuardLauncher {

  private Configuration _configuration;

  public ProGuardLauncher() {
    _configuration = new Configuration();
  }

  public void parseConfiguration(File file) throws ObclipseException {
    try {
      ConfigurationParser configurationparser = new ConfigurationParser(file);
      configurationparser.parse(_configuration);
      configurationparser.close();
    } catch (ParseException e) {
      Msg.error(e.getMessage(), e);
    } catch (IOException e) {
      Msg.ioException(file, e);
    }
  }

  public boolean execute() throws ObclipseException {
    try {
      ProGuard proguard = new ProGuard(_configuration);
      proguard.execute();
      return true;
    } catch (IOException e) {
      Msg.ioException(null, e);
    }
    return false;
  }

}
