/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.obfuscation.proguard;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import mfb2.tools.obclipse.ObclipseProps;
import mfb2.tools.obclipse.exceptions.ObclipseException;
import mfb2.tools.obclipse.io.TextFileWriter;
import mfb2.tools.obclipse.obfuscation.IObfuscator;
import mfb2.tools.obclipse.util.SystemInfo;

public class ProGuardObfuscator implements IObfuscator {

  public final static String DEFAULT_OBFUSCATION_PARAMETER_FILE = SystemInfo.OBCLIPSE_BASE_DIR + "obfuscationParameter.pro";

  public final static String DEFAULT_OBFUSCATION_CONFIG_FILE = SystemInfo.OBCLIPSE_BASE_DIR + "obfuscationConfig.pro";

  private String _obfuscationConfigFile = DEFAULT_OBFUSCATION_CONFIG_FILE;

  private String _obfuscationParameterFile = DEFAULT_OBFUSCATION_PARAMETER_FILE;

  public ProGuardObfuscator() {
    String obfuscationConfigFile = ObclipseProps.get(ObclipseProps.OBFUSCATOR_CONFIG_FILE);
    if (!"".equals(obfuscationConfigFile)) {
      _obfuscationConfigFile = obfuscationConfigFile;
    }
    String obfuscationParameterFile = ObclipseProps.get(ObclipseProps.OBFUSCATION_PARAMETER_FILE);
    if (!"".equals(obfuscationParameterFile)) {
      _obfuscationParameterFile = obfuscationParameterFile;
    }
  }

  public boolean executeObfucation() throws ObclipseException {
    ProGuardLauncher obfLauncher = new ProGuardLauncher();
    obfLauncher.parseConfiguration(new File(_obfuscationConfigFile));
    return obfLauncher.execute();
  }

  public boolean createObfuscatorConfiguration(File configFile, List<String> libraries, HashMap<String, String> obfuscationSources)
      throws ObclipseException {
    TextFileWriter configFileWriter = new TextFileWriter();
    configFileWriter.createConfigFile(new File(_obfuscationConfigFile));
    WriteProGuardConfigFile obfParameter = new WriteProGuardConfigFile(libraries, obfuscationSources);
    obfParameter.writeConfigFile(_obfuscationConfigFile, _obfuscationParameterFile);
    return false;
  }

  public HashMap<String, String> getObfuscatedClassNames(File mappingFile) throws ObclipseException {
    ProGuardObfuscationMapping obfuscationMapping = new ProGuardObfuscationMapping();
    obfuscationMapping.readMappingFile(new File(ObclipseProps.get(ObclipseProps.MAPPING_FILE_NAME)));
    return obfuscationMapping.getObfuscatedClassName();
  }

  /**
   * @see mfb2.tools.obclipse.obfuscation.IObfuscator#getDirectoriesToDelete()
   */
  public Set<String> getDirectoriesToDelete() throws ObclipseException {
    ProguardClassPathFilter proguardClassPathFilter = new ProguardClassPathFilter();
    return proguardClassPathFilter.getFilterBasePaths();
  }

}
