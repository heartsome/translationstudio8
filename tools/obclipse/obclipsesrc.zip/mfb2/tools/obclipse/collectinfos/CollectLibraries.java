/**
 * This file is part of Oblicpse.
 * Obclipse -- Obfuscating Eclipse Products
 * Copyright (c) 2007 Marco Bluemel (mfb2@users.sourceforge.net)
 * Website: http://obclipse.sourceforge.net/
 *
 * Obclipse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Obclipse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Obclipse.  If not, see <http://www.gnu.org/licenses/>.
 */
package mfb2.tools.obclipse.collectinfos;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import mfb2.tools.obclipse.ObclipseProps;
import mfb2.tools.obclipse.util.filefilter.AppPluginsFileFilter;
import mfb2.tools.obclipse.util.filefilter.PlattformFileFilter;

public class CollectLibraries {

  public CollectLibraries() {
  }

  public List<String> collectJars() {
    List<String> libraries = new ArrayList<String>();
    File sdkPluginDir = new File(ObclipseProps.get(ObclipseProps.APP_PLUGIN_DIR));
    if (sdkPluginDir.exists()) {
      File[] jars = sdkPluginDir.listFiles(new PlattformFileFilter());
      for (int i = 0; i < jars.length; i++) {
        libraries.add(jars[i].getAbsolutePath());
      }
    }
    File appDir = new File(ObclipseProps.get(ObclipseProps.APP_PLUGIN_DIR));
    if (appDir.exists()) {
      File[] appPluginDirs = appDir.listFiles(new AppPluginsFileFilter(false, true));
      for (File pluginDir : appPluginDirs) {

        for (String libDirPath : ObclipseProps.getListComma(ObclipseProps.PLUGIN_LIB_SUB_DIRS)) {
          File libDir = new File(pluginDir.getAbsolutePath() + File.separator + libDirPath);
          if (libDir.exists()) {
            File[] libs = libDir.listFiles();
            for (File jar : libs) {
              if (!jar.isDirectory() && jar.getName().endsWith(".jar")) { //$NON-NLS-1$
                libraries.add(jar.getAbsolutePath());
              }
            }
          }
        }
      }
    }
    return libraries;
  }

}
